import 'package:flutter/material.dart';
import 'lesson_list_screen.dart';
import 'signup_page.dart';
import 'login_page.dart';
import 'profile_page.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  List<_Module> get _modules => const [
    _Module(
      id: 'alphabet',
      title: 'Alphabet',
      color: Color(0xFFF2FF99),
      icon: Icons.abc_rounded,
    ),
    _Module(
      id: 'phrases',
      title: 'Phrases',
      color: Color(0xFFF2FF99),
      icon: Icons.chat_bubble_rounded,
    ),
    _Module(
      id: 'numbers',
      title: 'Numbers',
      color: Color(0xFFF2FF99),
      icon: Icons.onetwothree_rounded,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;

    return Scaffold(
      backgroundColor: const Color(0xFFEAF7FF),
      body: Stack(
        children: [
          // Gradient background
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFFB9F1FF), Color(0xFF3DD6F5)],
              ),
            ),
          ),

          SafeArea(
            child: Column(
              children: [
                // Top bar with single Login button
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Row(
                    children: [
                      const SizedBox(width: 8),
                      const Spacer(),
                      TextButton(
                        style: TextButton.styleFrom(
                          backgroundColor: const Color(0xFFEEC1C4),
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        ),
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => const LoginPage()),
                          );
                        },
                        child: const Text(
                          'Login',
                          style: TextStyle(color: Colors.black, fontWeight: FontWeight.w700),
                        ),
                      ),
                    ],
                  ),
                ),


                Padding(
                  padding: EdgeInsets.symmetric(horizontal: width > 600 ? 48 : 24),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text(
                              'DailySigns',
                              style: TextStyle(
                                fontSize: 42,
                                fontWeight: FontWeight.w900,
                                color: Colors.black87,
                              ),
                            ),
                            SizedBox(height: 6),
                            Text(
                              'Learn a little, sign a lot',
                              style: TextStyle(fontSize: 18,
                                  color: Colors.black87, fontWeight: FontWeight.bold),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 16),


                    ],
                  ),
                ),

                const SizedBox(height: 16),

                // Start Learning button with mascot
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: width > 600 ? 48 : 24),
                  child: Column(
                    children: [
                      const SizedBox(height: 8),
                      Container(
                        width: 46,
                        height: 46,
                        decoration: const BoxDecoration(
                          color: Colors.deepPurple,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.pets_rounded, color: Colors.white),
                      ),
                      const SizedBox(height: 10),
                      SizedBox(
                        width: 280,
                        height: 48,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF71E071),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
                            elevation: 0,
                          ),
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (_) => const SignUpPage()),
                            );
                          },
                          child: const Text(
                            'Start Learning',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w800,
                              color: Colors.black,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 26),

                // Learning Modules label
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: width > 600 ? 48 : 24),
                  child: const Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Learning Modules:',
                      style: TextStyle(fontSize: 18,
                          color: Colors.black87, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),

                const SizedBox(height: 16),

                // Modules row
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: width > 600 ? 40 : 18),
                  child: LayoutBuilder(
                    builder: (context, c) {
                      final isNarrow = c.maxWidth < 500;
                      final spacing = isNarrow ? 12.0 : 20.0;

                      return Wrap(
                        spacing: spacing,
                        runSpacing: spacing,
                        alignment: WrapAlignment.center,
                        children: _modules.map((m) {
                          return _ModuleCard(
                            module: m,
                            width: isNarrow ? (c.maxWidth - spacing) / 2 : 180,
                            onTap: () => _openModule(context, m),
                          );
                        }).toList(),
                      );
                    },
                  ),
                ),

                const Spacer(),

                // Bottom streak bar
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                  decoration: const BoxDecoration(
                    color: Color(0xFFE88686),
                    borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
                  ),
                  child: Row(
                    children: const [
                      Text(
                        'DAILY STREAK: 0',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
                      ),
                      SizedBox(width: 8),
                      Icon(Icons.local_fire_department_rounded, color: Colors.black87),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _openModule(BuildContext context, _Module m) {
    switch (m.id) {
      case 'alphabet':
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const LessonListScreen()),
        );
        break;
      case 'phrases':
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const LessonListScreen()),
        );
        break;
      case 'numbers':
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Numbers coming soon 🙂')),
        );
        break;
    }
  }
}

class _Module {
  final String id;
  final String title;
  final Color color;
  final IconData icon;
  const _Module({
    required this.id,
    required this.title,
    required this.color,
    required this.icon,
  });
}

class _ModuleCard extends StatelessWidget {
  const _ModuleCard({
    required this.module,
    required this.width,
    required this.onTap,
  });

  final _Module module;
  final double width;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: module.color,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Container(
          width: width,
          height: 90,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            boxShadow: const [
              BoxShadow(color: Color(0x1F000000), blurRadius: 10, offset: Offset(0, 4)),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(module.icon, size: 28, color: Colors.black87),
              const SizedBox(width: 10),
              Text(
                module.title,
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
