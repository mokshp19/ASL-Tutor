import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../../data/repositories/local_lesson_repository.dart';
import '../../domain/entities/lesson.dart';
import 'lessons_map.dart';

import '../../data/services/auth_service.dart';
import 'home_page.dart';
import 'profile_page.dart';
import 'login_page.dart';

class LessonListScreen extends StatefulWidget {
  const LessonListScreen({Key? key}) : super(key: key);

  @override
  State<LessonListScreen> createState() => _LessonListScreenState();
}

class _LessonListScreenState extends State<LessonListScreen> {
  final repo = LocalLessonRepository();
  late Future<List<Lesson>> lessonsFuture;

  @override
  void initState() {
    super.initState();
    lessonsFuture = repo.fetchLessons();
  }

  // ---------- helpers ----------
  bool _isAlphabet(Lesson l) => _keyFor(l) == 'alphabet';

  bool _isPhrases(Lesson l) {
    final k = _keyFor(l);
    return k == 'phrases' || k.contains('greet'); // catch "Common Greetings"
  }

  String _keyFor(Lesson l) =>
      (l.id.isNotEmpty ? l.id : l.title).replaceAll(' ', '_').toLowerCase();

  IconData _pickIconForTitle(String title) {
    final t = title.toLowerCase();
    if (t.contains('alphabet')) return Icons.abc_rounded;
    if (t.contains('greet') || t.contains('phrase')) return Icons.waving_hand_rounded;
    return Icons.school_rounded;
  }

  Color _pickColorForIndex(int i) {
    const palette = [
      Color(0xFFFFD166),
      Color(0xFFAFEEFF),
      Color(0xFFA0E7A0),
      Color(0xFFFFC1E3),
      Color(0xFFB4C5FF),
    ];
    return palette[i % palette.length];
  }

  Future<void> _logout() async {
    try {
      await AuthService.signOut();
    } catch (_) {}
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const HomePage()),
          (_) => false,
    );
  }

  // ---------- UI ----------
  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;

    return Scaffold(
      extendBody: true,
      backgroundColor: const Color(0xFFF7F9FC),
      appBar: AppBar(
        automaticallyImplyLeading: false,
        elevation: 0,
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.black87,
        title: const Text("ASL Tutor", style: TextStyle(fontWeight: FontWeight.w700)),
        centerTitle: false,
        actions: [
          IconButton(
            tooltip: 'Log out',
            icon: const Icon(Icons.logout_rounded),
            onPressed: _logout,
          ),
        ],
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFE8F3FF), Color(0xFFFFFFFF)],
          ),
        ),
        child: FutureBuilder<List<Lesson>>(
          future: lessonsFuture,
          builder: (context, snap) {
            if (snap.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snap.hasError) {
              return Center(child: Text('Error: ${snap.error}'));
            }

            final lessons = (snap.data ?? []);

            // Signed-out → guest view (locked modules)
            if (user == null) {
              return _buildGuestGrid(lessons);
            }

            // Stream the user doc for live stats (streak/xp/mistakes)
            final userDocStream = FirebaseFirestore.instance
                .collection('users')
                .doc(user.uid)
                .snapshots();

            return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
              stream: userDocStream,
              builder: (context, userSnap) {
                final userMap = userSnap.data?.data() ?? {};
                final int userStreak = (userMap['streak'] ?? 0) as int;
                final int userXp = (userMap['xp'] ?? 0) as int;
                // hearts = mistakes allowed (you can change this later)
                final int mistakesAllowed = (userMap['mistakesAllowed'] ?? 3) as int;

                // Stream progress docs for gating (% and unlocks)
                final keys = lessons.map(_keyFor).toSet().toList();
                final progressQuery = FirebaseFirestore.instance
                    .collection('users')
                    .doc(user.uid)
                    .collection('progress')
                    .where(
                  FieldPath.documentId,
                  whereIn: keys.length <= 10 ? keys : keys.take(10).toList(),
                )
                    .snapshots();

                return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                  stream: progressQuery,
                  builder: (context, progSnap) {
                    final progressByKey = <String, Map<String, dynamic>>{};
                    if (progSnap.hasData) {
                      for (final d in progSnap.data!.docs) {
                        progressByKey[d.id] = d.data();
                      }
                    }

                    // Unlock Phrases only when Alphabet is 100%
                    bool alphabetDone = false;
                    final a = progressByKey['alphabet'];
                    if (a != null) {
                      final completed = (a['completed'] as List?)?.length ?? 0;
                      final total = (a['totalLevels'] as int?) ?? 0;
                      alphabetDone = total > 0 && completed >= total;
                    }

                    return _buildGrid(
                      lessons: lessons,
                      progressByKey: progressByKey,
                      alphabetDone: alphabetDone,
                      userStreak: userStreak,
                      xp: userXp,
                      mistakesAllowed: mistakesAllowed,
                    );
                  },
                );
              },
            );
          },
        ),
      ),
      bottomNavigationBar: _BottomBar(
        onHome: () {},
        onLearn: () {},
        onPractice: () {},
        onProfile: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const ProfilePage()),
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: const Color(0xFF1DA1F2),
        icon: const Icon(Icons.local_fire_department),
        label: const Text("Practice"),
        onPressed: () {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Quick Practice coming soon 🔥")),
          );
        },
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }

  // Signed-in grid with gating and progress
  Widget _buildGrid({
    required List<Lesson> lessons,
    required Map<String, Map<String, dynamic>> progressByKey,
    required bool alphabetDone,
    required int userStreak,
    required int xp,
    required int mistakesAllowed,
  }) {
    // Signs learned = total completed levels across all modules
    int signsLearned = 0;
    for (final data in progressByKey.values) {
      final completed = (data['completed'] as List?)?.length ?? 0;
      signsLearned += completed;
    }

    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: _GameHUD(
            signsLearned: signsLearned,
            mistakesAllowed: mistakesAllowed,
            streak: userStreak,
            xp: xp,
          ),
        ),
        const SliverToBoxAdapter(child: SizedBox(height: 12)),
        const SliverToBoxAdapter(child: _DailyGoalCard()),
        const SliverToBoxAdapter(child: SizedBox(height: 8)),
        SliverPadding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          sliver: SliverGrid(
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              mainAxisSpacing: 16,
              crossAxisSpacing: 16,
              childAspectRatio: 0.9,
            ),
            delegate: SliverChildBuilderDelegate((_, i) {
              final l = lessons[i];
              final key = _keyFor(l);
              final color = _pickColorForIndex(i);
              final icon = _pickIconForTitle(l.title);

              // Firestore % (if present)
              int completed = 0, total = 0;
              if (progressByKey.containsKey(key)) {
                completed = (progressByKey[key]!['completed'] as List?)?.length ?? 0;
                total = (progressByKey[key]!['totalLevels'] as int?) ?? 0;
              }
              final fsPct = total > 0 ? completed / total : 0.0;

              // Lock logic: phrases unlocked only when alphabet is done
              bool unlocked = true;
              if (_isPhrases(l)) unlocked = alphabetDone;

              return Stack(
                clipBehavior: Clip.none,
                children: [
                  _LessonBubble(
                    title: l.title,
                    subtitle: l.description,
                    color: color,
                    icon: icon,
                    progress: fsPct,
                    unlocked: unlocked,
                    onTap: () {
                      if (!unlocked) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Finish Alphabet Basics to unlock this module.'),
                          ),
                        );
                        return;
                      }
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => LessonsMapScreen(
                            lesson: l,
                            totalLevels: _isAlphabet(l) ? 8 : 6, // alphabet(8) / phrases(6)
                          ),
                        ),
                      );
                    },
                  ),
                  Positioned(
                    top: -2,
                    right: -2,
                    child: _ModuleProgressBadge(
                      completed: completed,
                      total: total == 0 ? (_isAlphabet(l) ? 8 : 6) : total,
                    ),
                  ),
                ],
              );
            }, childCount: lessons.length),
          ),
        ),
        const SliverToBoxAdapter(child: SizedBox(height: 100)),
      ],
    );
  }

  // Guest mode: everything visible but locked. Tapping prompts sign-in.
  Widget _buildGuestGrid(List<Lesson> lessons) {
    return CustomScrollView(
      slivers: [
        const SliverToBoxAdapter(child: _GuestBanner()),
        const SliverToBoxAdapter(child: SizedBox(height: 8)),
        SliverPadding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          sliver: SliverGrid(
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              mainAxisSpacing: 16,
              crossAxisSpacing: 16,
              childAspectRatio: 0.9,
            ),
            delegate: SliverChildBuilderDelegate((_, i) {
              final l = lessons[i];
              final color = _pickColorForIndex(i);
              final icon = _pickIconForTitle(l.title);

              return _LessonBubble(
                title: l.title,
                subtitle: l.description,
                color: color,
                icon: icon,
                progress: 0.0, // no progress in guest mode
                unlocked: false, // locked
                onTap: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Sign in to start this module.')),
                  );
                },
              );
            }, childCount: lessons.length),
          ),
        ),
        const SliverToBoxAdapter(child: SizedBox(height: 100)),
      ],
    );
  }
}

/* -------------------- Small UI helpers -------------------- */

class _GuestBanner extends StatelessWidget {
  const _GuestBanner();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: const [
            BoxShadow(blurRadius: 8, offset: Offset(0, 4), color: Color(0x16000000))
          ],
        ),
        child: Row(
          children: [
            const Icon(Icons.lock_rounded),
            const SizedBox(width: 12),
            const Expanded(
              child: Text('Sign in to unlock modules and save your progress.'),
            ),
            TextButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const LoginPage()),
                );
              },
              child: const Text('Sign In'),
            )
          ],
        ),
      ),
    );
  }
}

class _ModuleProgressBadge extends StatelessWidget {
  const _ModuleProgressBadge({required this.completed, required this.total});
  final int completed;
  final int total;

  @override
  Widget build(BuildContext context) {
    final pct = total <= 0 ? 0.0 : (completed / total).clamp(0.0, 1.0);
    final label = pct >= 1 ? 'Done' : '${(pct * 100).round()}%';
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: pct >= 1 ? const Color(0xFF34C759) : Colors.black87,
        borderRadius: BorderRadius.circular(14),
        boxShadow: const [
          BoxShadow(color: Color(0x33000000), blurRadius: 6, offset: Offset(0, 3))
        ],
      ),
      child: Text(
        label,
        style:
        const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 12),
      ),
    );
  }
}

class _GameHUD extends StatelessWidget {
  const _GameHUD({
    required this.signsLearned,
    required this.mistakesAllowed,
    required this.streak,
    required this.xp,
  });

  final int signsLearned;    // 🏆
  final int mistakesAllowed; // ❤️ Mistakes allowed
  final int streak;          // 🔥
  final int xp;              // ⭐

  @override
  Widget build(BuildContext context) {
    Widget tile(IconData icon, String value) => Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [
          BoxShadow(blurRadius: 8, offset: Offset(0, 4), color: Color(0x1F000000)),
        ],
      ),
      child: Row(
        children: [
          Icon(icon, size: 20, color: Colors.black87),
          const SizedBox(width: 6),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w700)),
        ],
      ),
    );

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          tile(Icons.emoji_events_rounded, '$signsLearned'),
          const SizedBox(width: 12),
          tile(Icons.favorite_rounded, '$mistakesAllowed'),
          const SizedBox(width: 12),
          tile(Icons.local_fire_department_rounded, '$streak'),
          const SizedBox(width: 12),
          tile(Icons.star_rate_rounded, '$xp XP'),
        ],
      ),
    );
  }
}

class _DailyGoalCard extends StatelessWidget {
  const _DailyGoalCard();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: const [
            BoxShadow(blurRadius: 8, offset: Offset(0, 4), color: Color(0x19000000))
          ],
        ),
        child: Row(
          children: [
            const Icon(Icons.bolt_rounded, size: 28),
            const SizedBox(width: 12),
            const Expanded(
              child: Text(
                "Daily goal: 10 min • Keep your streak alive!",
                style: TextStyle(fontWeight: FontWeight.w600),
              ),
            ),
            TextButton(onPressed: () {}, child: const Text("Set goal")),
          ],
        ),
      ),
    );
  }
}

class _LessonBubble extends StatelessWidget {
  const _LessonBubble({
    required this.title,
    required this.subtitle,
    required this.color,
    required this.icon,
    required this.progress,
    required this.unlocked,
    required this.onTap,
  });

  final String title;
  final String subtitle;
  final Color color;
  final IconData icon;
  final double progress; // 0..1
  final bool unlocked;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final bubble = Stack(
      alignment: Alignment.center,
      children: [
        TweenAnimationBuilder<double>(
          tween: Tween(begin: 0, end: progress),
          duration: const Duration(milliseconds: 800),
          curve: Curves.easeOutCubic,
          builder: (_, value, __) => CustomPaint(
            size: const Size(120, 120),
            painter: _RingPainter(
              value,
              trackColor: Colors.white.withOpacity(0.7),
              fillColor: color,
            ),
          ),
        ),
        Container(
          width: 90,
          height: 90,
          decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
            boxShadow: const [
              BoxShadow(blurRadius: 10, offset: Offset(0, 6), color: Color(0x33000000))
            ],
          ),
          child: Icon(icon, size: 44, color: Colors.black87),
        ),
        if (!unlocked)
          Container(
            width: 90,
            height: 90,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.65),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.lock_rounded, size: 34, color: Colors.black87),
          ),
      ],
    );

    return InkWell(
      borderRadius: BorderRadius.circular(24),
      onTap: unlocked ? onTap : null,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          bubble,
          const SizedBox(height: 10),
          Text(
            title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 2),
          Text(
            subtitle,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(color: Colors.black.withOpacity(0.6), fontSize: 12),
          ),
          const SizedBox(height: 6),
          _StarRow(progress: progress),
        ],
      ),
    );
  }
}

class _StarRow extends StatelessWidget {
  const _StarRow({required this.progress});
  final double progress;

  @override
  Widget build(BuildContext context) {
    final filled =
    (progress >= 0.9 ? 3 : progress >= 0.6 ? 2 : progress >= 0.3 ? 1 : 0);
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(3, (i) {
        final on = i < filled;
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 2),
          child: Icon(on ? Icons.star : Icons.star_border, size: 16),
        );
      }),
    );
  }
}

class _RingPainter extends CustomPainter {
  _RingPainter(this.value, {required this.trackColor, required this.fillColor});
  final double value;
  final Color trackColor;
  final Color fillColor;

  @override
  void paint(Canvas canvas, Size size) {
    final stroke = 10.0;
    final rect = Offset.zero & size;
    final center = rect.center;
    final radius = (size.shortestSide / 2) - stroke / 2;

    final track = Paint()
      ..color = trackColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke
      ..strokeCap = StrokeCap.round;

    final fill = Paint()
      ..shader = SweepGradient(
        colors: [fillColor.withOpacity(0.95), fillColor.withOpacity(0.6)],
        startAngle: 0,
        endAngle: 6.28318,
      ).createShader(rect)
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke
      ..strokeCap = StrokeCap.round;

    canvas.drawCircle(center, radius, track);

    final sweep = value.clamp(0.0, 1.0) * 6.28318;
    const start = -3.14159 / 2;
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      start,
      sweep,
      false,
      fill,
    );
  }

  @override
  bool shouldRepaint(covariant _RingPainter old) => old.value != value;
}

class _BottomBar extends StatelessWidget {
  const _BottomBar({
    required this.onHome,
    required this.onLearn,
    required this.onPractice,
    required this.onProfile,
  });

  final VoidCallback onHome, onLearn, onPractice, onProfile;

  @override
  Widget build(BuildContext context) {
    return BottomAppBar(
      shape: const CircularNotchedRectangle(),
      notchMargin: 8,
      height: 64,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          IconButton(icon: const Icon(Icons.home_rounded), onPressed: onHome),
          IconButton(icon: const Icon(Icons.menu_book_rounded), onPressed: onLearn),
          const SizedBox(width: 48),
          IconButton(icon: const Icon(Icons.shield_rounded), onPressed: onPractice),
          IconButton(icon: const Icon(Icons.person_rounded), onPressed: onProfile),
        ],
      ),
    );
  }
}
