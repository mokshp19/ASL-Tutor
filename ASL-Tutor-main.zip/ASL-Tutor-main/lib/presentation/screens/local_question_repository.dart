// lib/data/repositories/local_question_repository.dart
import '../../domain/entities/lesson.dart';
import '../../presentation/screens/question.dart';

class LocalQuestionRepository {
  Future<List<Question>> getQuestions({
    required Lesson lesson,
    required int levelIndex,
  }) async {
    final title = lesson.title.toLowerCase();
    if (title.contains('alphabet')) {
      return _alphabetLevel(levelIndex);
    } else if (title.contains('greet')) {
      return _greetingsLevel(levelIndex);
    }
    return _alphabetLevel(levelIndex);
  }

  Future<List<Question>> _alphabetLevel(int levelIndex) async {
    switch (levelIndex) {
      case 0:
        return const [
          Question(id: 'a0', prompt: "Which is the ASL for 'A'?", choices: ['A','B','C','D'], correctIndex: 0),
          Question(id: 'a1', prompt: "Which is the ASL for 'B'?", choices: ['C','B','D','E'], correctIndex: 1),
          Question(id: 'a2', prompt: "Which is the ASL for 'C'?", choices: ['C','A','B','E'], correctIndex: 0),
          Question(id: 'a3', prompt: "Pick the letter that matches this sign: 'D'", choices: ['B','D','F','G'], correctIndex: 1),
          Question(id: 'a4', prompt: "Pick the letter that matches this sign: 'E'", choices: ['E','H','G','I'], correctIndex: 0),
        ];
      case 1:
        return const [
          Question(id: 'b0', prompt: "Which is 'F'?", choices: ['F','H','J','K'], correctIndex: 0),
          Question(id: 'b1', prompt: "Which is 'G'?", choices: ['I','G','H','L'], correctIndex: 1),
          Question(id: 'b2', prompt: "Which is 'H'?", choices: ['H','M','N','O'], correctIndex: 0),
          Question(id: 'b3', prompt: "Which is 'I'?", choices: ['Q','R','I','S'], correctIndex: 2),
          Question(id: 'b4', prompt: "Which is 'J'?", choices: ['J','T','U','V'], correctIndex: 0),
        ];
      default:
        return const [
          Question(id: 'c0', prompt: "Which is 'K'?", choices: ['K','L','M','N'], correctIndex: 0),
          Question(id: 'c1', prompt: "Which is 'L'?", choices: ['P','L','R','S'], correctIndex: 1),
          Question(id: 'c2', prompt: "Which is 'M'?", choices: ['M','T','U','V'], correctIndex: 0),
          Question(id: 'c3', prompt: "Which is 'N'?", choices: ['W','N','X','Y'], correctIndex: 1),
          Question(id: 'c4', prompt: "Which is 'O'?", choices: ['O','Z','A','B'], correctIndex: 0),
        ];
    }
  }

  Future<List<Question>> _greetingsLevel(int levelIndex) async {
    return const [
      Question(id: 'g0', prompt: "How do you sign 'Hello'?", choices: ['Hello','Bye','Thanks','Yes'], correctIndex: 0),
      Question(id: 'g1', prompt: "How do you sign 'Thank you'?", choices: ['Sorry','Thanks','Please','Hello'], correctIndex: 1),
      Question(id: 'g2', prompt: "How do you sign 'Please'?", choices: ['Please','Yes','No','Ok'], correctIndex: 0),
      Question(id: 'g3', prompt: "How do you sign 'Sorry'?", choices: ['Hello','Thanks','Sorry','Bye'], correctIndex: 2),
      Question(id: 'g4', prompt: "How do you sign 'Goodbye'?", choices: ['Bye','Hello','Please','Thanks'], correctIndex: 0),
    ];
  }
}
