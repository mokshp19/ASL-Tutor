import 'package:flutter/material.dart';
import '../../domain/entities/lesson.dart';
import 'package:flutter/material.dart';
import '../../data/repositories/local_lesson_repository.dart';
import 'local_question_repository.dart';
import 'question.dart';

// class PracticeScreen extends StatefulWidget {
//   final Lesson lesson;
//   const PracticeScreen({Key? key, required this.lesson}) : super(key: key);
//
//   @override
//   State<PracticeScreen> createState() => _PracticeScreenState();
// }
//
// class _PracticeScreenState extends State<PracticeScreen> {
//   int currentQuestion = 1;
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: Text(widget.lesson.title)),
//       body: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Text("Question $currentQuestion / ${widget.lesson.totalQuestions}",
//                 style: const TextStyle(fontSize: 18)),
//             const SizedBox(height: 20),
//             const Text(
//               "Which sign represents the letter A?",
//               style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
//             ),
//             const SizedBox(height: 20),
//             Expanded(
//               child: ListView(
//                 children: [
//                   ElevatedButton(
//                       onPressed: () {}, child: const Text("Option 1")),
//                   ElevatedButton(
//                       onPressed: () {}, child: const Text("Option 2")),
//                   ElevatedButton(
//                       onPressed: () {}, child: const Text("Option 3")),
//                 ],
//               ),
//             )
//           ],
//         ),
//       ),
//     );
//   }
// }

class PracticeScreen extends StatefulWidget {
  const PracticeScreen({
    super.key,
    required this.lesson,
    this.levelIndex = 0, // <- from the map
  });

  final Lesson lesson;
  final int levelIndex;

  @override
  State<PracticeScreen> createState() => _PracticeScreenState();
}

class _PracticeScreenState extends State<PracticeScreen> {
  final repo = LocalQuestionRepository();

  late Future<List<Question>> _questionsFuture;
  List<Question> _questions = const [];
  int _index = 0;
  bool _answered = false;
  int _selected = -1;
  bool _allCorrectSoFar = true;

  @override
  void initState() {
    super.initState();
    _questionsFuture = repo.getQuestions(
      lesson: widget.lesson,
      levelIndex: widget.levelIndex,
    );
  }

  void _selectChoice(int i) {
    if (_answered) return;
    setState(() {
      _selected = i;
      _answered = true;
      final current = _questions[_index];
      final correct = i == current.correctIndex;
      if (!correct) _allCorrectSoFar = false;
    });

    // Small pause to show feedback color
    Future.delayed(const Duration(milliseconds: 600), _nextOrFinish);
  }

  void _nextOrFinish() {
    if (_index + 1 < _questions.length) {
      setState(() {
        _index++;
        _answered = false;
        _selected = -1;
      });
    } else {
      // Finished all questions
      if (_allCorrectSoFar) {
        // PASS: perfect score required
        _showResultDialog(pass: true, onClose: () {
          Navigator.pop(context, true); // tells the map to advance
        });
      } else {
        // FAIL: return false and force restart from map
        _showResultDialog(pass: false, onClose: () {
          Navigator.pop(context, false); // stays on same platform
        });
      }
    }
  }

  void _showResultDialog({required bool pass, required VoidCallback onClose}) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: Text(pass ? "Perfect! 🎉" : "Try again 🔁"),
        content: Text(pass
            ? "You got all answers correct. Great job!"
            : "You must answer all 5 correctly to pass this lesson. Restart from the map."),
        actions: [
          TextButton(onPressed: onClose, child: Text(pass ? "Continue" : "OK")),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("${widget.lesson.title} • L${widget.levelIndex + 1}"),
      ),
      body: FutureBuilder<List<Question>>(
        future: _questionsFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text("Error: ${snapshot.error}"));
          }
          _questions = snapshot.data ?? const [];
          if (_questions.isEmpty) {
            return const Center(child: Text("No questions for this level yet."));
          }

          final q = _questions[_index];

          return Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                // Progress
                Row(
                  children: [
                    Expanded(
                      child: LinearProgressIndicator(
                        value: (_index + 1) / _questions.length,
                        minHeight: 10,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Text("${_index + 1}/${_questions.length}"),
                  ],
                ),
                const SizedBox(height: 24),

                // Prompt
                Text(
                  q.prompt,
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 16),

                // Optional image
                if (q.imageAsset != null)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 16),
                    child: Image.asset(q.imageAsset!, height: 160, fit: BoxFit.contain),
                  ),

                const SizedBox(height: 8),

                // Choices
                Expanded(
                  child: ListView.separated(
                    itemCount: q.choices.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 12),
                    itemBuilder: (_, i) {
                      final choice = q.choices[i];
                      final isSelected = _selected == i;
                      final isCorrect = i == q.correctIndex;

                      // After answering: green correct, red wrong; before → neutral
                      Color bg;
                      if (_answered) {
                        if (isCorrect) {
                          bg = Colors.green.shade100;
                        } else if (isSelected && !isCorrect) {
                          bg = Colors.red.shade100;
                        } else {
                          bg = Colors.white;
                        }
                      } else {
                        bg = Colors.white;
                      }

                      return Material(
                        color: bg,
                        borderRadius: BorderRadius.circular(14),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(14),
                          onTap: () => _selectChoice(i),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                            child: Row(
                              children: [
                                Icon(
                                  _answered
                                      ? (isCorrect ? Icons.check_circle : (isSelected ? Icons.cancel : Icons.circle_outlined))
                                      : Icons.circle_outlined,
                                  color: _answered
                                      ? (isCorrect ? Colors.green : (isSelected ? Colors.red : Colors.grey))
                                      : Colors.grey,
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Text(
                                    choice,
                                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

