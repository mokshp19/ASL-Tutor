import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class Achievement {
  final String id;
  final String title;
  final String description;
  final IconData icon;
  final Color color;
  final int requirement;
  final String statKey;

  const Achievement({
    required this.id,
    required this.title,
    required this.description,
    required this.icon,
    required this.color,
    required this.requirement,
    required this.statKey,
  });

  bool unlocked(int value) => value >= requirement;
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  List<Achievement> get achievements => [
        Achievement(
          id: 'streak3',
          title: 'On Fire',
          description: '3-day streak',
          icon: Icons.local_fire_department,
          color: Colors.orange,
          requirement: 3,
          statKey: 'longestStreak',
        ),
        Achievement(
          id: 'streak7',
          title: 'Dedicated',
          description: '7-day streak',
          icon: Icons.flash_on,
          color: Colors.yellow,
          requirement: 7,
          statKey: 'longestStreak',
        ),
        Achievement(
          id: 'streak30',
          title: 'Consistency Master',
          description: '30-day streak',
          icon: Icons.stars,
          color: Colors.purple,
          requirement: 30,
          statKey: 'longestStreak',
        ),
        Achievement(
          id: 's10',
          title: 'First Steps',
          description: 'Learn 10 signs',
          icon: Icons.front_hand,
          color: Colors.blue,
          requirement: 10,
          statKey: 'signsLearned',
        ),
        Achievement(
          id: 's50',
          title: 'Conversationalist',
          description: 'Learn 50 signs',
          icon: Icons.waving_hand,
          color: Colors.green,
          requirement: 50,
          statKey: 'signsLearned',
        ),
        Achievement(
          id: 's100',
          title: 'ASL Expert',
          description: 'Learn 100 signs',
          icon: Icons.emoji_events,
          color: Colors.amber,
          requirement: 100,
          statKey: 'signsLearned',
        ),
        Achievement(
          id: 'xp500',
          title: 'Rising Star',
          description: 'Earn 500 XP',
          icon: Icons.auto_awesome,
          color: Colors.cyan,
          requirement: 500,
          statKey: 'totalXp',
        ),
        Achievement(
          id: 'xp1000',
          title: 'Superstar',
          description: 'Earn 1,000 XP',
          icon: Icons.star,
          color: Colors.yellow,
          requirement: 1000,
          statKey: 'totalXp',
        ),
        Achievement(
          id: 'xp5000',
          title: 'Legend',
          description: 'Earn 5,000 XP',
          icon: Icons.workspace_premium,
          color: Colors.deepPurple,
          requirement: 5000,
          statKey: 'totalXp',
        ),
        Achievement(
          id: 't60',
          title: 'Committed',
          description: '1 hour practice',
          icon: Icons.schedule,
          color: Colors.teal,
          requirement: 60,
          statKey: 'timeMinutes',
        ),
        Achievement(
          id: 't300',
          title: 'Scholar',
          description: '5 hours practice',
          icon: Icons.school,
          color: Colors.indigo,
          requirement: 300,
          statKey: 'timeMinutes',
        ),
        Achievement(
          id: 't600',
          title: 'Master Student',
          description: '10 hours practice',
          icon: Icons.military_tech,
          color: Colors.red,
          requirement: 600,
          statKey: 'timeMinutes',
        ),
      ];

  int toInt(dynamic v) {
    if (v is int) return v;
    if (v is num) return v.toInt();
    return int.tryParse(v.toString()) ?? 0;
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      return Scaffold(
        body: Center(child: Text('Please sign in')),
      );
    }

    final userDoc =
        FirebaseFirestore.instance.collection('users').doc(user.uid).snapshots();

    final progressDocs = FirebaseFirestore.instance
        .collection('users')
        .doc(user.uid)
        .collection('progress')
        .snapshots();

    return Scaffold(
      backgroundColor: const Color(0xFFEAF7FF),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text('Profile'),
      ),
      body: StreamBuilder(
        stream: userDoc,
        builder: (context, userSnap) {
          final u = userSnap.data?.data() ?? {};

          final streak = toInt(u['streak']);
          final longestStreak = toInt(u['longestStreak']);
          final xp = toInt(u['xp']);
          final timeMinutes = toInt(u['timeSpentMinutes']);
          final storedSigns = toInt(u['signsLearned']);

          return StreamBuilder(
            stream: progressDocs,
            builder: (context, progSnap) {
              int levels = 0;
              if (progSnap.hasData) {
                for (var d in progSnap.data!.docs) {
                  levels += (d['completed'] as List?)?.length ?? 0;
                }
              }

              final signs = storedSigns > 0 ? storedSigns : levels * 3;

              final statMap = {
                'longestStreak': longestStreak,
                'signsLearned': signs,
                'totalXp': xp,
                'timeMinutes': timeMinutes,
              };

              final unlockedCount = achievements
                  .where((a) => a.unlocked(statMap[a.statKey] ?? 0))
                  .length;

              return SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(children: [
                      CircleAvatar(
                        radius: 40,
                        backgroundColor: Colors.green,
                        child: Icon(Icons.person, size: 40, color: Colors.white),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Text(
                          user.email ?? '',
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      )
                    ]),
                    const SizedBox(height: 30),

                    _stat('Current Streak', '$streak days'),
                    _stat('Longest Streak', '$longestStreak days'),
                    _stat('Total XP', '$xp XP'),
                    _stat('Time Spent', '${timeMinutes}m'),
                    _stat('Signs Learned', '$signs'),

                    const SizedBox(height: 28),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Achievements',
                            style: TextStyle(
                                fontSize: 20, fontWeight: FontWeight.w700)),
                        Text('$unlockedCount/${achievements.length}',
                            style: const TextStyle(
                                fontWeight: FontWeight.w700)),
                      ],
                    ),
                    const SizedBox(height: 16),

                    // 3 badges per row auto-fit
                    Wrap(
                      spacing: 10,
                      runSpacing: 10,
                      children: achievements.map((a) {
                        final current = statMap[a.statKey] ?? 0;
                        final unlocked = a.unlocked(current);

                        return LayoutBuilder(
                          builder: (context, constraints) {
                            final screenWidth =
                                MediaQuery.of(context).size.width;

                            final badgeWidth =
                                (screenWidth - 20 - 20 - 20) / 3;

                            return SizedBox(
                              width: badgeWidth,
                              child: _badge(a, current, unlocked),
                            );
                          },
                        );
                      }).toList(),
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }

  Widget _stat(String title, String value) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          Expanded(
              child: Text(title,
                  style: const TextStyle(
                      fontWeight: FontWeight.w700, fontSize: 16))),
          Text(value,
              style:
                  const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
        ],
      ),
    );
  }

  Widget _badge(Achievement a, int current, bool unlocked) {
    final fade = unlocked ? 1.0 : 0.45;
    final progress = (current / a.requirement).clamp(0.0, 1.0);

    return Opacity(
      opacity: fade,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: a.color.withOpacity(0.35),
            width: 2,
          ),
        ),
        child: Column(
          children: [
            Container(
              width: 62,
              height: 62,
              decoration: BoxDecoration(
                color: a.color.withOpacity(0.22),
                shape: BoxShape.circle,
              ),
              child: Icon(a.icon, size: 34, color: a.color),
            ),
            const SizedBox(height: 8),

            Text(
              a.title,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w700,
              ),
            ),

            const SizedBox(height: 4),

            Text(
              a.description,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w500,
              ),
            ),

            const SizedBox(height: 8),

            LinearProgressIndicator(
              value: progress,
              backgroundColor: Colors.grey.shade300,
              valueColor: AlwaysStoppedAnimation(a.color),
              minHeight: 6,
            ),
          ],
        ),
      ),
    );
  }
}
