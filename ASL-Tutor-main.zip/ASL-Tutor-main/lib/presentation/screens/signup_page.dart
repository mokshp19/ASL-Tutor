import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'lesson_list_screen.dart';
import '../../data/services/auth_service.dart';
import 'home_page.dart';

class SignUpPage extends StatefulWidget {
  const SignUpPage({super.key});

  @override
  State<SignUpPage> createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _pass = TextEditingController();
  final _confirm = TextEditingController();
  bool _obscure = true;

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _pass.dispose();
    _confirm.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    try {
      await AuthService.signUp(
        name: _name.text.trim(),
        email: _email.text.trim(),
        password: _pass.text,
      );

      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const LessonListScreen()),
      );
    } on FirebaseAuthException catch (e) {
      String msg;
      switch (e.code) {
        case 'email-already-in-use':
          msg = 'That email is already registered. Try logging in instead.';
          break;
        case 'invalid-email':
          msg = 'That email address looks invalid.';
          break;
        case 'weak-password':
          msg = 'Password is too weak. Use at least 6 characters.';
          break;
        case 'network-request-failed':
          msg = 'Network error. Please check your connection.';
          break;
        case 'operation-not-allowed':
          msg = 'Email/password sign-in is disabled for this project.';
          break;
        default:
          msg = 'Sign up failed: ${e.message ?? e.code}';
      }
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Sign up failed: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;

    return Scaffold(
      body: Stack(
        children: [
          // Gradient background
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFFCCF2FF), Color(0xFF2C74B3)],
              ),
            ),
          ),
          // Pink “blobs”
          const _Blob(top: -20, left: -20),
          const _Blob(top: -18, right: -24),
          const _Blob(left: -16, bottom: 140),
          const _Blob(right: -16, bottom: 80),

          SafeArea(
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(
                horizontal: w > 600 ? 48 : 24,
                vertical: 16,
              ),
              child: Column(
                children: [
                  Align(
                    alignment: Alignment.topLeft,
                    child: IconButton(
                      icon: const Icon(Icons.arrow_back,
                          size: 40, color: Colors.black),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const HomePage(),
                          ),
                        );
                      },
                    ),
                  ),

                  const Text(
                    "Welcome!",
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                      fontStyle: FontStyle.italic,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    "Let’s begin learning, one sign\nat a time",
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.white,
                      fontStyle: FontStyle.italic,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 18),

                  // Illustration
                  ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Image.asset(
                      'assets/images/sign_teaching.jpg',
                      width: 170,
                      height: 170,
                      fit: BoxFit.cover,
                      semanticLabel: 'ASL teaching illustration',
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    "Image Source:",
                    style: TextStyle(color: Colors.white, fontSize: 14),
                  ),

                  const SizedBox(height: 4),
                  const Text(
                    "https://www.istockphoto.com/search/2/image?mediatype=illustration&phrase=child+sign+language",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 8,
                    ),
                    textAlign: TextAlign.center,
                  ),




                  const SizedBox(height: 24),

                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      "Your Information",
                      style: TextStyle(
                        fontSize: 22,
                        color: Colors.white.withOpacity(0.95),
                        fontStyle: FontStyle.italic,
                        decoration: TextDecoration.underline,
                        decorationColor: Colors.white70,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),

                  // Form
                  Form(
                    key: _formKey,
                    child: Column(
                      children: [
                        _LabeledField(
                          label: "Name:",
                          child: TextFormField(
                            controller: _name,
                            textInputAction: TextInputAction.next,
                            decoration: _fieldDecoration(),
                            validator: (v) => (v == null || v.trim().isEmpty)
                                ? "Please enter your name"
                                : null,
                          ),
                        ),
                        const SizedBox(height: 12),
                        _LabeledField(
                          label: "Email:",
                          child: TextFormField(
                            controller: _email,
                            keyboardType: TextInputType.emailAddress,
                            textInputAction: TextInputAction.next,
                            decoration: _fieldDecoration(),
                            validator: (v) {
                              if (v == null || v.isEmpty) {
                                return "Please enter your email";
                              }
                              final ok =
                              RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(v);
                              return ok ? null : "Enter a valid email";
                            },
                          ),
                        ),
                        const SizedBox(height: 12),
                        _LabeledField(
                          label: "Password:",
                          child: TextFormField(
                            controller: _pass,
                            obscureText: _obscure,
                            textInputAction: TextInputAction.next,
                            decoration: _fieldDecoration().copyWith(
                              suffixIcon: IconButton(
                                icon: Icon(_obscure
                                    ? Icons.visibility
                                    : Icons.visibility_off),
                                onPressed: () =>
                                    setState(() => _obscure = !_obscure),
                              ),
                            ),
                            validator: (v) => (v == null || v.length < 6)
                                ? "Password must be at least 6 characters"
                                : null,
                          ),
                        ),
                        const SizedBox(height: 12),
                        _LabeledField(
                          label: "Confirm Password:",
                          child: TextFormField(
                            controller: _confirm,
                            obscureText: _obscure,
                            decoration: _fieldDecoration(),
                            validator: (v) =>
                            (v != _pass.text) ? "Passwords don’t match" : null,
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 22),

                  // Get Started button
                  SizedBox(
                    width: 260,
                    height: 52,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF71E071),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(28),
                        ),
                        elevation: 0,
                      ),
                      onPressed: _submit,
                      child: const Text(
                        "Get Started",
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w800,
                          color: Colors.black,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  InputDecoration _fieldDecoration() {
    return InputDecoration(
      filled: true,
      fillColor: Colors.white.withOpacity(0.85),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(24),
        borderSide: BorderSide.none,
      ),
      contentPadding:
      const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
    );
  }
}

/* ---------- helpers ---------- */

class _LabeledField extends StatelessWidget {
  const _LabeledField({required this.label, required this.child});
  final String label;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        SizedBox(
          width: 120,
          child: Text(
            label,
            style: const TextStyle(
              color: Colors.white,
              fontStyle: FontStyle.italic,
              fontSize: 16,
            ),
          ),
        ),
        Expanded(child: child),
      ],
    );
  }
}

class _Blob extends StatelessWidget {
  const _Blob({this.top, this.left, this.right, this.bottom});
  final double? top, left, right, bottom;

  @override
  Widget build(BuildContext context) {
    return Positioned(
      top: top,
      left: left,
      right: right,
      bottom: bottom,
      child: Container(
        width: 120,
        height: 80,
        decoration: const BoxDecoration(
          color: Color(0xFFFF8F8F),
          borderRadius: BorderRadius.all(Radius.circular(60)),
        ),
      ),
    );
  }
}
