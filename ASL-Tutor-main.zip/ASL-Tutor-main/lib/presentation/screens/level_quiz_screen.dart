import 'package:flutter/material.dart';
import '../../data/services/progress_service.dart';

class LevelQuizScreen extends StatefulWidget {
  const LevelQuizScreen({
    Key? key,
    required this.lessonTitle,
    required this.levelIndex,
  }) : super(key: key);

  final String lessonTitle;
  final int levelIndex;

  @override
  State<LevelQuizScreen> createState() => _LevelQuizScreenState();
}

class _LevelQuizScreenState extends State<LevelQuizScreen> {
  late final List<_Q> _questions;
  int _current = 0;
  int _correct = 0;

 @override
  void initState() {
    super.initState();
    _questions = _buildQuestions(widget.lessonTitle, widget.levelIndex);
    ProgressService.startSession();
  }

  /// Build different questions depending on:
  /// - module (Alphabet Basics vs Phrases/Common Greetings vs others)
  /// - level index
  List<_Q> _buildQuestions(String lessonTitle, int levelIndex) {
    final title = lessonTitle.toLowerCase();

    // =========================
    // 1) ALPHABET BASICS MODULE
    // =========================
    if (title.contains('alphabet')) {
      switch (levelIndex) {
      // -------- LEVEL 1 — A, B, C --------
        case 0:
          return [
            _Q(
              prompt: 'Which ASL handshape represents the letter A?',
              choices: const [
                'A. Handshape 1',
                'B. Handshape 2',
                'C. Handshape 3',
              ],
              correctIndex: 0, // A
              imageAsset: 'assets/images/alpha_l1_q1.jpg',
              creditLink: 'https://www.signingsavvy.com/browse/A',
            ),
            _Q(
              prompt: 'Select the ASL sign for the letter B.',
              choices: const [
                'A. Option 1',
                'B. Option 2',
                'C. Option 3',
              ],
              correctIndex: 1, // B
              imageAsset: 'assets/images/alpha_l1_q1.jpg',
              creditLink: 'https://www.signingsavvy.com/browse/B',
            ),
            _Q(
              prompt: 'What letter does this ASL sign represent?',
              choices: const [
                'A. A',
                'B. B',
                'C. C',
              ],
              correctIndex: 2, // C
              imageAsset: 'assets/images/alpha_l1_q3.jpg',
              creditLink: 'https://www.redbubble.com/i/sticker/C-American-Sign-Language-by-Kliethermes28/37150225.EJUG5',
            ),
          ];

      // -------- LEVEL 2 — D, E, F --------
        case 1:
          return [
            _Q(
              prompt: 'Which ASL sign matches the letter D?',
              choices: const [
                'A. Option 1',
                'B. Option 2',
                'C. Option 3',
              ],
              correctIndex: 0, // D
              imageAsset: 'assets/images/alpha_l2_q1.jpg',
              creditLink: 'https://www.signingsavvy.com/browse/D',
            ),
            _Q(
              prompt: 'What letter is this ASL handshape showing?',
              choices: const [
                'A. D',
                'B. E',
                'C. F',
              ],
              correctIndex: 1, // E
              imageAsset: 'assets/images/alpha_l2_q2.jpg',
              creditLink: 'https://www.signingsavvy.com/browse/E',
            ),
            _Q(
              prompt: 'Choose the correct ASL letter for this handshape:',
              choices: const [
                'A. O',
                'B. F',
                'C. P',
              ],
              correctIndex: 1, // F
              imageAsset: 'assets/images/alpha_l2_q3.jpg',
              creditLink: 'https://www.signingsavvy.com/browse/F',
            ),
          ];

      // -------- LEVEL 3 — G, H, I --------
        case 2:
          return [
            _Q(
              prompt: 'Which ASL letter uses a sideways pointing gesture?',
              choices: const [
                'A. G',
                'B. H',
                'C. I',
              ],
              correctIndex: 0, // G
              imageAsset: 'assets/images/alpha_l3_q1.jpg',
              creditLink: 'https://www.signingsavvy.com/browse/G',
            ),
            _Q(
              prompt: 'Match this ASL sign with the correct letter:',
              choices: const [
                'A. G',
                'B. H',
                'C. I',
              ],
              correctIndex: 1, // H
              imageAsset: 'assets/images/alpha_l3_q2.jpg',
              creditLink: 'https://www.signingsavvy.com/browse/H',
            ),
            _Q(
              prompt: 'What letter does this pinky-up handshape represent?',
              choices: const [
                'A. I',
                'B. J',
                'C. Y',
              ],
              correctIndex: 0, // I
              imageAsset: 'assets/images/alpha_l3_q3.jpg',
              creditLink: 'https://www.signingsavvy.com/browse/I',
            ),
          ];

      // -------- LEVEL 4 — J, K, L --------
        case 3:
          return [
            _Q(
              prompt: 'Which ASL sign represents the letter L?',
              choices: const [
                'A. L',
                'B. J',
                'C. K',
              ],
              correctIndex: 0, // L
              imageAsset: 'assets/images/alpha_l4_q1.jpg',
              creditLink: 'https://www.signingsavvy.com/browse/L',
            ),
            _Q(
              prompt: 'The ASL letter J uses which type of movement?',
              choices: const [
                'A. Circle',
                'B. Swipe down',
                'C. Curve shaped like a “J”',
                'D. No movement',
              ],
              correctIndex: 2, // C
              imageAsset: 'assets/images/alpha_l4_q2.jpg',
              creditLink: 'https://www.signingsavvy.com/browse/J',
            ),
            _Q(
              prompt: 'Select the correct ASL handshape for the letter K.',
              choices: const [
                'A. Handshape 1',
                'B. Handshape 2',
                'C. Handshape 3',
              ],
              correctIndex: 0, // depends on your layout
              imageAsset: 'assets/images/alpha_l4_q3.jpg',
              creditLink: 'https://www.signingsavvy.com/browse/K',
            ),
          ];

      // -------- LEVEL 5 — M, N, O --------
        case 4:
          return [
            _Q(
              prompt: 'What letter does this ASL sign represent?',
              choices: const [
                'A. M',
                'B. N',
                'C. S',
              ],
              correctIndex: 0, // M
              imageAsset: 'assets/images/alpha_l5_q1.jpg',
              creditLink: 'https://www.signingsavvy.com/browse/M',
            ),
            _Q(
              prompt: 'Which sign shows the letter N?',
              choices: const [
                'A. Option 1',
                'B. Option 2',
                'C. Option 3',
              ],
              correctIndex: 1, // N
              imageAsset: 'assets/images/alpha_l5_q2.jpg',
              creditLink: 'https://www.signingsavvy.com/browse/N',
            ),
            _Q(
              prompt: 'Select the ASL sign for the letter O.',
              choices: const [
                'A. Option 1',
                'B. Option 2',
                'C. Option 3',
              ],
              correctIndex: 2, // O
              imageAsset: 'assets/images/alpha_l5_q3.jpg',
              creditLink: 'https://www.signingsavvy.com/browse/O',
            ),
          ];

      // -------- LEVEL 6 — P, Q, R --------
        case 5:
          return [
            _Q(
              prompt: 'Which ASL sign represents the letter P?',
              choices: const [
                'A. Option 1',
                'B. Option 2',
                'C. Option 3',
              ],
              correctIndex: 1, // P
              imageAsset: 'assets/images/alpha_l6_q1.jpg',
              creditLink: 'https://www.signingsavvy.com/browse/P',
            ),
            _Q(
              prompt: 'What letter is this handshape showing?',
              choices: const [
                'A. G',
                'B. Q',
                'C. P',
              ],
              correctIndex: 1, // Q
              imageAsset: 'assets/images/alpha_l6_q2.jpg',
              creditLink: 'https://www.signingsavvy.com/browse/Q',
            ),
            _Q(
              prompt: 'Choose the correct ASL letter for this handshape:',
              choices: const [
                'A. O',
                'B. R',
                'C. A',
              ],
              correctIndex: 1, // R
              imageAsset: 'assets/images/alpha_l6_q3.jpg',
              creditLink: 'https://www.signingsavvy.com/browse/R',
            ),
          ];

      // -------- LEVEL 7 — V, W, X --------
        case 6:
          return [
            _Q(
              prompt: 'Which ASL sign has two fingers spread apart?',
              choices: const [
                'A. V',
                'B. U',
                'C. W',
              ],
              correctIndex: 0, // V
              imageAsset: 'assets/images/alpha_l7_q1.jpg',
              creditLink: 'https://www.signingsavvy.com/browse/V',
            ),
            _Q(
              prompt: 'What letter does this handshape represent?',
              choices: const [
                'A. V',
                'B. W',
                'C. X',
              ],
              correctIndex: 1, // W
              imageAsset: 'assets/images/alpha_l7_q2.jpg',
              creditLink: 'https://www.signingsavvy.com/browse/W',
            ),
            _Q(
              prompt: 'Select the ASL sign for the letter X.',
              choices: const [
                'A. X',
                'B. Y',
                'C. Z',
              ],
              correctIndex: 0, // X
              imageAsset: 'assets/images/alpha_l7_q3.jpg',
              creditLink: 'https://www.signingsavvy.com/browse/X',
            ),
          ];

      // -------- LEVEL 8 — Y, Z + Review --------
        case 7:
          return [
            _Q(
              prompt: 'Which ASL sign represents the letter Y?',
              choices: const [
                'A. Thumb & pinky out',
                'B. Heart handshape',
                'C. Upside-down W handshape',
              ],
              correctIndex: 0, // Y
              imageAsset: 'assets/images/alpha_l8_q1.jpg',
              creditLink: 'https://www.signingsavvy.com/browse/Y',
            ),
            _Q(
              prompt: 'Does this ASL sign represent the letter Z?',
              choices: const [
                'A. I don’t know',
                'B. True',
                'C. False',
              ],
              correctIndex: 1, // True
              imageAsset: 'assets/images/alpha_l8_q2.jpg',
              creditLink: 'https://www.signingsavvy.com/browse/Z',
            ),
            _Q(
              prompt: 'You have learned all of the alphabet letters. Was this fun?',
              choices: const [
                'A. Yes',
                'B. No',
                'C. Not sure',
              ],
              correctIndex: 0,
              imageAsset: 'assets/images/alpha_l8_q3.jpg',
              creditLink: 'https://en.wikipedia.org/wiki/Thumb_signal',
            ),
          ];
      }
    }

    // ============================================
    // 2) PHRASES / COMMON GREETINGS MODULE
    // ============================================
    if (title.contains('phrase') || title.contains('greet')) {
      switch (levelIndex) {
      // 🌟 LEVEL 1 — Basic Hello & Goodbye
        case 0:
          return [
            _Q(
              prompt: 'Does this sign mean “HELLO”?',
              choices: const [
                'A. I don’t know',
                'B. Yes',
                'C. No',
              ],
              correctIndex: 1, // Yes
              imageAsset: 'assets/images/phr_l1_q1.gif',
              creditLink:
              'https://giphy.com/stickers/simax-deaf-sign-language-gehrlos-DcPfy7StVKeB5dv0ND',
            ),
            _Q(
              prompt: 'What does this sign mean?',
              choices: const [
                'A. Goodbye',
                'B. Please',
                'C. Thank you',
                'D. Sorry',
              ],
              correctIndex: 0, // Goodbye
              imageAsset: 'assets/images/phr_l1_q2.gif',
              creditLink:
              'https://giphy.com/gifs/signwithrobert-sign-with-robert-3o7TKzb3i29i86BPJm',
            ),
            _Q(
              prompt: 'Choose the sign you would use when you first see someone.',
              choices: const [
                'A. HELLO',
                'B. THANK YOU',
                'C. SORRY',
                'D. GOOD NIGHT',
              ],
              correctIndex: 0, // HELLO
              imageAsset: 'assets/images/phr_l1_q1.gif', //keep this as is
              creditLink:
              'https://giphy.com/stickers/simax-deaf-sign-language-gehrlos-DcPfy7StVKeB5dv0ND',
            ),
          ];

      // 🌟 LEVEL 2 — Thank You, Please, Sorry
        case 1:
          return [
            _Q(
              prompt: 'What does this sign mean?',
              choices: const [
                'A. Thank you',
                'B. Hello',
                'C. Good',
                'D. Yes',
              ],
              correctIndex: 0, // Thank you
              imageAsset: 'assets/images/phr_l2_q1.gif',
              creditLink:
              'https://giphy.com/gifs/cartoonnetwork-craig-of-the-creek-cotc-LTCoyo48bFUC0ODGzi',
            ),
            _Q(
              prompt: 'Does the flat-hand-on-chest gesture mean "PLEASE"?',
              choices: const [
                'A. No',
                'B. I don’t know',
                'C. Yes',
              ],
              correctIndex: 2, // Yes
              imageAsset: 'assets/images/phr_l2_q2.gif',
              creditLink:
              'https://giphy.com/gifs/asl-please-por-favor-IAjOzVWbdqHEu3pjZG',
            ),
            _Q(
              prompt:
              'You accidentally bump into someone. Which sign is most appropriate?',
              choices: const [
                'A. HELLO',
                'B. SORRY',
                'C. GOODBYE',
                'D. THANK YOU',
              ],
              correctIndex: 1, // SORRY
              imageAsset: 'assets/images/phr_l2_q3.gif',
              creditLink:
              'https://www.pinterest.com/pin/new-party-member-tags-sorry-sign-language-sign-with-robert-deaf-american-sign-language-swr--9077636733520383/',
            ),
          ];

      // 🌟 LEVEL 3 — Yes / No / Good
        case 2:
          return [
            _Q(
              prompt: 'What does this sign mean?',
              choices: const [
                'A. Yes',
                'B. No',
                'C. Maybe',
                'D. Good',
              ],
              correctIndex: 0, // Yes
              imageAsset: 'assets/images/phr_l3_q1.gif',
              creditLink:
              'https://giphy.com/stickers/simax-deaf-sign-language-gehrlos-vnLw7fc3Bk8K3HifLv',
            ),
            _Q(
              prompt: 'The sign above means “YES”?',
              choices: const [
                'A. True (it means YES)',
                'B. False (it means NO)',
                'C. I don’t know',
              ],
              correctIndex: 1, // False
              imageAsset: 'assets/images/phr_l3_q2.gif',
              creditLink:
              'https://giphy.com/gifs/simax-no-sign-language-eenRMPBYE2jy80Fur9',
            ),
            _Q(
              prompt:
              'This sign is used to say something is positive or okay. What does it mean?',
              choices: const [
                'A. Good',
                'B. Sorry',
                'C. Please',
                'D. Later',
              ],
              correctIndex: 0, // Good
              imageAsset: 'assets/images/phr_l3_q3.gif',
              creditLink:
              'https://www.lifeprint.com/asl101/pages-signs/g/good.htm',
            ),
          ];

      // 🌟 LEVEL 4 — How Are You? & Basic Questions
        case 3:
          return [
            _Q(
              prompt: 'What does this sign mean?',
              choices: const [
                'A. How are you?',
                'B. Where are you?',
                'C. What is your name?',
                'D. Good night',
              ],
              correctIndex: 0, // How are you?
              imageAsset: 'assets/images/phr_l4_q1.gif',
              creditLink:
              'https://giphy.com/gifs/signwithrobert-sign-with-robert-3o7TKDw5NA17fKJVWU',
            ),
            _Q(
              prompt: 'Which sign would you use to ask someone’s name?',
              choices: const [
                'A. WHAT’S YOUR NAME?',
                'B. HELLO',
                'C. GOODBYE',
                'D. THANK YOU',
              ],
              correctIndex: 0, // What's your name?
              imageAsset: 'assets/images/phr_l4_q2.gif',
              creditLink:
              'https://giphy.com/gifs/signwithrobert-sign-with-robert-3o7TKDJBonanzESryE',
            ),
            _Q(
              prompt:
              'You want to ask a new friend how they are doing. Which ASL phrase do you choose?',
              choices: const [
                'A. HOW ARE YOU?',
                'B. THANK YOU',
                'C. GOODBYE',
                'D. GOOD MORNING',
              ],
              correctIndex: 0, // HOW ARE YOU?
              imageAsset: 'assets/images/phr_l4_q1.gif', //keep this as is
              creditLink:
              'https://giphy.com/gifs/signwithrobert-sign-with-robert-3o7TKDw5NA17fKJVWU',
            ),
          ];

      // 🌟 LEVEL 5 — Time-of-Day Greetings
        case 4:
          return [
            _Q(
              prompt: 'Which greeting do you use in the morning?',
              choices: const [
                'A. GOOD MORNING',
                'B. GOOD NIGHT',
                'C. HELLO',
                'D. THANK YOU',
              ],
              correctIndex: 0, // GOOD MORNING
              imageAsset: 'assets/images/phr_l5_q1.gif',
              creditLink:
              'https://jp.pinterest.com/pin/507358714291378847/',
            ),
            _Q(
              prompt: 'What does this sign mean?',
              choices: const [
                'A. Good night',
                'B. Good morning',
                'C. Goodbye',
                'D. See you later',
              ],
              correctIndex: 0, // Good night
              imageAsset: 'assets/images/phr_l5_q2.gif',
              creditLink:
              'https://id.pinterest.com/pin/77757531055364099/',
            ),
            _Q(
              prompt: 'You see someone in the afternoon. Which greeting fits best?',
              choices: const [
                'A. GOOD AFTERNOON',
                'B. GOOD NIGHT',
                'C. SORRY',
                'D. PLEASE',
              ],
              correctIndex: 0, // GOOD AFTERNOON
              imageAsset: 'assets/images/phr_l5_q3.gif',
              creditLink:
              'https://giphy.com/gifs/signwithrobert-sign-with-robert-l4JzaRsX52k8glIFa',
            ),
          ];

      // 🌟 LEVEL 6 — Simple Conversations & Closings
        case 5:
          return [
            _Q(
              prompt: 'What is the best response to “HOW ARE YOU?”',
              choices: const [
                'A. I’M FINE.',
                'B. MY NAME…',
                'C. GOODBYE.',
                'D. PLEASE.',
              ],
              correctIndex: 0, // I'm fine
              imageAsset: 'assets/images/phr_l6_q1.gif',
              creditLink:
              'https://ru.pinterest.com/pin/75153887516671343/',
            ),
            _Q(
              prompt: 'This sign means “NICE TO MEET YOU.” When would you use it?',
              choices: const [
                'A. When meeting someone for the first time',
                'B. When saying good night',
                'C. When saying sorry',
                'D. When asking for a name',
              ],
              correctIndex: 0, // meeting first time
              imageAsset: 'assets/images/phr_l6_q2.gif',
              creditLink:
              'https://www.pinterest.com/pin/nice-to-meet-you-sign-language-gif-nice-to-meet-you-sign-language-simax-discover-share-gifs--20899585765388802/',
            ),
            _Q(
              prompt:
              'You’re leaving a conversation politely. Which sign should you use?',
              choices: const [
                'A. GOODBYE',
                'B. HOW ARE YOU',
                'C. THANK YOU',
                'D. YES',
              ],
              correctIndex: 0, // GOODBYE
              imageAsset: 'assets/images/phr_l1_q2.gif', //keep this as is
              creditLink:
              'https://giphy.com/gifs/signwithrobert-sign-with-robert-3o7TKzb3i29i86BPJm',
            ),
          ];
      }
    }

    // =========================
    // 3) OTHER MODULES (fallback)
    // =========================
    return [
      _Q(
        prompt: 'What letter is shown?',
        choices: const [
          'A. A',
          'B. B',
          'C. C',
        ],
        correctIndex: 0,
        imageAsset: 'assets/images/default_q1.png',
        creditLink: 'Add credit link for fallback Q1',
      ),
      _Q(
        prompt: 'Pick the matching sign for "B".',
        choices: const [
          'A. A',
          'B. B',
          'C. C',
        ],
        correctIndex: 1,
        imageAsset: 'assets/images/default_q2.png',
        creditLink: 'Add credit link for fallback Q2',
      ),
      _Q(
        prompt: 'Which one is a vowel?',
        choices: const [
          'A. D',
          'B. C',
          'C. E',
        ],
        correctIndex: 2,
        imageAsset: 'assets/images/default_q3.png',
        creditLink: 'Add credit link for fallback Q3',
      ),
    ];
  }

  void _answer(int choice) {
    final q = _questions[_current];


    if (choice == q.correctIndex) {
      _correct++;
      _nextQuestion();
    }
    else{
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Incorrect Option Chosen'),
          content: Text('The option selected "${q.choices[choice]}" is incorrect'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                _nextQuestion();
              },
              child: const Text('OK'),
            ),
          ],
        ),
      );
    }
  }

  void _nextQuestion(){
      if (_current < _questions.length - 1) {
        setState(() => _current++);
      }

      else {
        // Pass rule: at least 70% correct
        final needed = (_questions.length * 0.7).ceil();
        final passed = _correct >= needed;
        Navigator.pop(context, passed);
      }
  }

  @override
  void dispose() {
    ProgressService.stopSession();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final q = _questions[_current];

    return Scaffold(
      appBar: AppBar(
        title: Text(
          '${widget.lessonTitle} • Level ${widget.levelIndex + 1}',
          style: const TextStyle(fontSize: 16),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Card(
          elevation: 2,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Text(
                  q.prompt,
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 16),

                // ---------- Image placeholder + credit text ----------
                if (q.imageAsset != null)
                  Column(
                    children: [
                      Container(
                        width: double.infinity,
                        height: 160,
                        margin: const EdgeInsets.only(bottom: 8),
                        decoration: BoxDecoration(
                          color: Colors.grey.shade200,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Colors.grey.shade400),
                        ),
                        child: Image.asset(
                          q.imageAsset!,
                          fit: BoxFit.contain,
                          errorBuilder: (context, error, stackTrace) {
                            return Center(
                              child: Text(
                                'Failed to load:\n${q.imageAsset}',
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  fontSize: 12,
                                  color: Colors.red,
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                      if (q.creditLink != null)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 12.0),
                          child: Text(
                            'Image credit: ${q.creditLink}',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 11,
                              color: Colors.grey.shade700,
                            ),
                          ),
                        ),
                    ],
                  ),

                // ---------- Choices ----------
                ...List.generate(q.choices.length, (i) {
                  return Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () => _answer(i),
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: Text(q.choices[i]),
                    ),
                  );
                }),
                const Spacer(),
                Text('Question ${_current + 1} of ${_questions.length}'),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _Q {
  final String prompt;
  final List<String> choices; // e.g., ['A. ...', 'B. ...', 'C. ...']
  final int correctIndex; // 0 = A, 1 = B, 2 = C, ...
  final String? imageAsset; // e.g., 'assets/images/alpha_l1_q1.png'
  final String? creditLink; // literal text credit (URL or note)

  const _Q({
    required this.prompt,
    required this.choices,
    required this.correctIndex,
    this.imageAsset,
    this.creditLink,
  });
}
