import 'package:flutter/material.dart';
import 'lesson_list_screen.dart';
import '../../data/services/auth_service.dart';

import 'home_page.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}




class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>();
  final _email = TextEditingController();
  final _pass = TextEditingController();
  bool _obscure = true;

  @override
  void dispose() {
    _email.dispose();
    _pass.dispose();
    super.dispose();
  }

  void _submit() async {
    if (!_formKey.currentState!.validate()) return;
    try {
      await AuthService.signIn(
        email: _email.text.trim(),
        password: _pass.text,
      );
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const LessonListScreen()),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Login failed: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;

    return Scaffold(
      body: Stack(
        children: [
          // Gradient background
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter, end: Alignment.bottomCenter,
                colors: [Color(0xFFCCF2FF), Color(0xFF2C74B3)],
              ),
            ),
          ),
          // Pink blobs (corners)
          const _Blob(top: -20, left: -20),
          const _Blob(top: -18, right: -24),
          const _Blob(left: -16, bottom: 120),
          const _Blob(right: -16, bottom: 60),

          SafeArea(
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: w > 600 ? 48 : 24, vertical: 16),
              child: Column(

                children: [

                  Align (

                    alignment: Alignment.topLeft,

                    child: IconButton(
                        icon: Icon(Icons.arrow_back, size: 40, color: Colors.black),

                        onPressed:(){
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder:(_) => const HomePage()),
                          );
                        },
                    ),
                  ),


                  const Text(
                    "Welcome!",
                    style: TextStyle(
                      fontSize: 28, fontWeight: FontWeight.w700, color: Colors.white,
                      fontStyle: FontStyle.italic,
                    ),
                    textAlign: TextAlign.center,
                  ),




                  const SizedBox(height: 10),
                  const Text(
                    "Good to see you again 👋 Ready to learn\nmore?",
                    style: TextStyle(
                      fontSize: 20, color: Colors.white, fontStyle: FontStyle.italic,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 18),

                  // Illustration placeholder — swap with your asset if you want
                  ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Image.asset(
                      'assets/images/signing_language.png',
                      width: 170,
                      height: 170,
                      fit: BoxFit.cover,
                      semanticLabel: 'ASL teaching illustration',
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    "Image Source:",
                    style: TextStyle(color: Colors.white, fontSize: 14),
                  ),

                  const SizedBox(height: 4),
                  const Text(
                    "https://www.istockphoto.com/search/2/image?mediatype=illustration&phrase=child+sign+language",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 8,
                    ),
                    textAlign: TextAlign.center,
                  ),


                  const SizedBox(height: 22),

                  // “Login” title with underline + tiny mascot
                  Row(
                    children: [
                      // mascot
                      Container(
                        width: 36,
                        height: 36,
                        decoration: const BoxDecoration(
                          color: Colors.deepPurple,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.pets_rounded, size: 20, color: Colors.white),
                      ),
                      const SizedBox(width: 10),
                      Text(
                        "Login",
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.95),
                          fontSize: 22,
                          decoration: TextDecoration.underline,
                          decorationColor: Colors.white70,
                          fontStyle: FontStyle.italic,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),

                  // Form
                  Form(
                    key: _formKey,
                    child: Column(
                      children: [
                        _LabeledField(
                          label: "Email:",
                          child: TextFormField(
                            controller: _email,
                            keyboardType: TextInputType.emailAddress,
                            textInputAction: TextInputAction.next,
                            decoration: _fieldDecoration(),
                            validator: (v) {
                              if (v == null || v.isEmpty) return "Please enter your email";
                              final ok = RegExp(r'^[^@]+@[^@]+\.[^@]+$').hasMatch(v);
                              return ok ? null : "Enter a valid email";
                            },
                          ),
                        ),
                        const SizedBox(height: 14),
                        _LabeledField(
                          label: "Password:",
                          child: TextFormField(
                            controller: _pass,
                            obscureText: _obscure,
                            decoration: _fieldDecoration().copyWith(
                              suffixIcon: IconButton(
                                icon: Icon(_obscure ? Icons.visibility : Icons.visibility_off),
                                onPressed: () => setState(() => _obscure = !_obscure),
                              ),
                            ),
                            validator: (v) => (v == null || v.isEmpty) ? "Please enter your password" : null,
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 26),

                  // Get Started button
                  SizedBox(
                    width: 260,
                    height: 52,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF71E071),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
                        elevation: 0,
                      ),
                      onPressed: _submit,
                      child: const Text(
                        "Get Started",
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: Colors.black),
                      ),
                    ),
                  ),

                  const SizedBox(height: 24),

                  // Bottom streak bar (static sample)
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                    decoration: const BoxDecoration(
                      color: Color(0xFFE88686),
                      borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
                    ),
                    child: Row(
                      children: const [
                        Text("DAILY STREAK: 0",
                            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
                        SizedBox(width: 8),
                        Icon(Icons.local_fire_department_rounded, color: Colors.black87),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  InputDecoration _fieldDecoration() {
    return InputDecoration(
      filled: true,
      fillColor: Colors.white.withOpacity(0.85),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(24),
        borderSide: BorderSide.none,
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
    );
  }
}



class _LabeledField extends StatelessWidget {
  const _LabeledField({required this.label, required this.child});
  final String label;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        SizedBox(
          width: 120,
          child: Text(
            label,
            style: const TextStyle(
              color: Colors.white,
              fontStyle: FontStyle.italic,
              fontSize: 16,
            ),
          ),
        ),
        Expanded(child: child),
      ],
    );
  }
}

class _Blob extends StatelessWidget {
  const _Blob({this.top, this.left, this.right, this.bottom});
  final double? top, left, right, bottom;

  @override
  Widget build(BuildContext context) {
    return Positioned(
      top: top, left: left, right: right, bottom: bottom,
      child: Container(
        width: 120, height: 80,
        decoration: const BoxDecoration(
          color: Color(0xFFFF8F8F),
          borderRadius: BorderRadius.all(Radius.circular(60)),
        ),
      ),
    );
  }
}
