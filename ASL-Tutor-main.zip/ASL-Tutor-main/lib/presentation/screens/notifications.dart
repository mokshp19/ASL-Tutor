import 'package:flutter/material.dart';

import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'dart:io' show Platform;
import 'dart:async';
import 'package:permission_handler/permission_handler.dart';

import 'home_page.dart';

class NotificationPage extends StatefulWidget {
  const NotificationPage({Key? key}) : super(key: key);
  @override
  _NotificationPageState createState() => _NotificationPageState();
}

class _NotificationPageState extends State<NotificationPage> {
  late FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin;
  int _countdown = 2;
  Timer? _timer;
  bool _notificationShown = false;

  @override
  void initState() {
    super.initState();

    flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

    const AndroidInitializationSettings initializationSettingsAndroid =
    AndroidInitializationSettings('@mipmap/ic_launcher');

    const DarwinInitializationSettings initializationSettingsIOS =
    DarwinInitializationSettings(
      requestAlertPermission: false,
      requestBadgePermission: false,
      requestSoundPermission: false,
    );

    const InitializationSettings initializationSettings = InitializationSettings(
      android: initializationSettingsAndroid,
      iOS: initializationSettingsIOS
    );

    flutterLocalNotificationsPlugin.initialize(
      initializationSettings,
      onDidReceiveNotificationResponse:
          (NotificationResponse notificationResponse) {
        onSelectNotification(notificationResponse.payload);
        print("Notification tapped!");
      },
    );

    if (Platform.isIOS) {
      _requestIOSPermissions();
    } else if (Platform.isAndroid) {
      _requestAndroidPermissions();
      final isGranted = Permission.notification.isGranted;
      print('Notification permission granted? $isGranted');
    }

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await Future.delayed(const Duration(seconds: 1));
      await showDelayedNotification();
    });
  }

  Future<void> _requestIOSPermissions() async {
    final IOSFlutterLocalNotificationsPlugin? iosImplementation =
    flutterLocalNotificationsPlugin.resolvePlatformSpecificImplementation<
        IOSFlutterLocalNotificationsPlugin>();

    final bool? granted = await iosImplementation?.requestPermissions(
      alert: true,
      badge: true,
      sound: true,
    );

    if (granted == true) {
      print("iOS notification permission granted");
    } else {
      print("iOS notification permission denied");
    }
  }

  Future<void> _requestAndroidPermissions() async {
    if (await Permission.notification.isDenied) {
      PermissionStatus status = await Permission.notification.request();
      if (status.isGranted) {
        print("Android notification permission granted");
      } else {
        print("Android notification permission denied");
      }
    }
  }

  Future<void> onSelectNotification(String? payload) async {
    if (payload != null) {
      print('Notification payload received: $payload');
    }
  }

  Future<void> showDelayedNotification() async {
    _startCountdown();

    await Future.delayed(Duration(seconds: 2), () async {
      const AndroidNotificationDetails androidPlatformChannelSpecifics =
      AndroidNotificationDetails(
        'your_channel_id',
        'your_channel_name',
        channelDescription: 'Notifications channel',
        importance: Importance.max,
        priority: Priority.high,
      );

      const DarwinNotificationDetails iosPlatformChannelSpecifics =
      DarwinNotificationDetails(
        presentAlert: true,
        presentBadge: true,
        presentSound: true,
      );

      const NotificationDetails platformChannelSpecifics = NotificationDetails(
        android: androidPlatformChannelSpecifics,
        iOS: iosPlatformChannelSpecifics,
      );

      print('Showing delayed notification');
      await flutterLocalNotificationsPlugin.show(
        0,
        'Welcome Back!',
        "You're on a 7 day streak!.",
        platformChannelSpecifics,
        payload: 'Login successful',
      );
    });
  }

  void _startCountdown() {
    setState(() {
      _countdown = 2;
    });

    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      setState(() {
        if (_countdown > 1) {
          _countdown -= 1;
        } else {
          _countdown = 0;
          _timer?.cancel();
        }
      });
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return const HomePage();
  }
}