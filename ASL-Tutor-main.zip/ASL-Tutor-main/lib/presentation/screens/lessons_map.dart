import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../../domain/entities/lesson.dart';
import '../../data/services/progress_service.dart';
import 'level_quiz_screen.dart';

/// LessonsMapScreen
/// - Shows N levels for a module (e.g., Alphabet Basics, Phrases)
/// - Unlocks levels sequentially (must pass level i to unlock i+1)
/// - Progress is saved to: users/{uid}/progress/{lessonKey}
class LessonsMapScreen extends StatefulWidget {
  const LessonsMapScreen({
    Key? key,
    required this.lesson,
    required this.totalLevels,
  }) : super(key: key);

  final Lesson lesson;
  final int totalLevels;

  @override
  State<LessonsMapScreen> createState() => _LessonsMapScreenState();
}

class _LessonsMapScreenState extends State<LessonsMapScreen> {
  late final String _lessonKey; // prefer lesson.id, fallback to normalized title
  late final User? _user;
  bool _loading = true;

  /// Completed flags (by index) for local UI state.
  late List<bool> _completed;

  DocumentReference<Map<String, dynamic>> get _docRef {
    final uid = _user!.uid;
    return FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .collection('progress')
        .doc(_lessonKey);
  }

  @override
  void initState() {
    super.initState();
    _lessonKey = (widget.lesson.id.isNotEmpty
        ? widget.lesson.id
        : widget.lesson.title)
        .replaceAll(' ', '_')
        .toLowerCase();

    _completed = List<bool>.filled(widget.totalLevels, false);
    _user = FirebaseAuth.instance.currentUser;
    _init();
  }

  Future<void> _init() async {
    if (_user == null) {
      if (mounted) {
        setState(() => _loading = false);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Please sign in to track progress.')),
        );
      }
      return;
    }

    try {
      final snap = await _docRef.get();
      if (snap.exists) {
        final data = snap.data()!;
        final raw = (data['completed'] as List?)?.cast<dynamic>() ?? [];
        for (final v in raw) {
          final idx = (v is int) ? v : int.tryParse(v.toString());
          if (idx != null && idx >= 0 && idx < _completed.length) {
            _completed[idx] = true;
          }
        }
      } else {
        // seed doc
        await _docRef.set({
          'completed': [],
          'totalLevels': widget.totalLevels,
          'updatedAt': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not load progress: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  bool _isUnlocked(int index) {
    if (index == 0) return true;
    return _completed[index - 1];
  }

  Future<void> _openLevel(int index) async {
    if (!_isUnlocked(index)) return;

    final passed = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => LevelQuizScreen(
          lessonTitle: widget.lesson.title,
          levelIndex: index,
        ),
      ),
    );

    if (passed == true && !_completed[index]) {

      setState(() => _completed[index] = true);


      try {
        await ProgressService.markLevelComplete(
          lessonKey: _lessonKey,
          levelIndex: index,
          totalLevels: widget.totalLevels,
        );
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Saved locally, but could not sync progress: $e')),
          );
        }
      }

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Level ${index + 1} complete! '
                '${index + 1 < widget.totalLevels ? "Next level unlocked." : "All levels finished 🎉"}',
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final lesson = widget.lesson;

    return Scaffold(
      appBar: AppBar(
        title: Text(lesson.title),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0.5,
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFF7FBFF), Color(0xFFEFF5FF)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: ListView.builder(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
          itemCount: widget.totalLevels + 1,
          itemBuilder: (context, i) {
            if (i == 0) return _HeaderCard(lesson: lesson);

            final idx = i - 1;
            final unlocked = _isUnlocked(idx);
            final done = _completed[idx];

            return _LevelTile(
              index: idx,
              unlocked: unlocked,
              completed: done,
              onTap: () => _openLevel(idx),
            );
          },
        ),
      ),
    );
  }
}



class _HeaderCard extends StatelessWidget {
  const _HeaderCard({required this.lesson});
  final Lesson lesson;

  @override
  Widget build(BuildContext context) {
    return Card(
      color: const Color(0xFF34C759),
      margin: const EdgeInsets.only(bottom: 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            const Icon(Icons.abc_rounded, color: Colors.white, size: 36),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    lesson.title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w800,
                      fontSize: 18,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    lesson.description,
                    style: const TextStyle(color: Colors.white),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _LevelTile extends StatelessWidget {
  const _LevelTile({
    required this.index,
    required this.unlocked,
    required this.completed,
    required this.onTap,
  });

  final int index;
  final bool unlocked;
  final bool completed;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final number = index + 1;
    final bg = completed
        ? const Color(0xFFE8FFF0)
        : unlocked
        ? Colors.white
        : const Color(0xFFF3F5F8);

    final icon = completed
        ? Icons.check_circle_rounded
        : unlocked
        ? Icons.star_border_rounded
        : Icons.lock_rounded;

    final iconColor = completed
        ? const Color(0xFF34C759)
        : (unlocked ? Colors.black54 : Colors.black26);

    return InkWell(
      onTap: unlocked ? onTap : null,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 8),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(16),
          boxShadow: unlocked
              ? [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 8,
              offset: const Offset(0, 4),
            )
          ]
              : null,
        ),
        child: Row(
          children: [
            CircleAvatar(
              radius: 20,
              backgroundColor:
              unlocked ? const Color(0xFFFFF3C4) : const Color(0xFFE6E9EE),
              child: Text(
                '$number',
                style: TextStyle(
                  fontWeight: FontWeight.w800,
                  color: unlocked ? Colors.black87 : Colors.black38,
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                'Level $number',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: unlocked ? Colors.black87 : Colors.black45,
                ),
              ),
            ),
            Icon(icon, color: iconColor),
          ],
        ),
      ),
    );
  }
}
