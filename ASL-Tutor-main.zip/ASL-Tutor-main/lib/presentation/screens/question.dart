// lib/presentation/lessons/question.dart

class Question {
  final String id;
  final String prompt;              // e.g., "Select the sign for 'A'"
  final List<String> choices;       // label per choice
  final int correctIndex;           // index into choices
  final String? imageAsset;         // optional (e.g., 'assets/asl/a.png')

  const Question({
    required this.id,
    required this.prompt,
    required this.choices,
    required this.correctIndex,
    this.imageAsset,
  });
}
