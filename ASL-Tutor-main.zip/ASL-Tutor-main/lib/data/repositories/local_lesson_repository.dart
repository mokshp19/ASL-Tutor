// lib/data/repositories/local_question_repository.dart
import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;
import '../../domain/entities/lesson.dart';
import '../../domain/repositories/lesson_repository.dart';
import '../../domain/entities/lesson.dart';
import '../../presentation/screens/question.dart';


// class LocalLessonRepository implements LessonRepository {
//   final String jsonAssetPath;
//
//   LocalLessonRepository({this.jsonAssetPath = 'assets/data/lessons.json'});
//
//   List<Lesson>? _cache;
//
//   @override
//   Future<List<Lesson>> fetchLessons() async {
//     if (_cache != null) return _cache!;
//     final raw = await rootBundle.loadString(jsonAssetPath);
//     final list = (json.decode(raw) as List<dynamic>);
//     _cache = list.map((e) => Lesson.fromJson(e)).toList();
//     return _cache!;
//   }
//
//   @override
//   Future<Lesson?> fetchLessonById(String id) async {
//     final all = await fetchLessons();
//     try {
//       return all.firstWhere((lesson) => lesson.id == id);
//     } catch (_) {
//       return null;
//     }
//
//   }
// }

class LocalLessonRepository {
  Future<List<Lesson>> fetchLessons() async {
    // Temporary hardcoded lessons
    return const [
      Lesson(
        id: 'alphabet',
        title: 'Alphabet Basics',
        description: 'Learn A–E and beyond', totalQuestions: 5,
      ),
      Lesson(
        id: 'greetings',
        title: 'Common Greetings',
        description: 'Hello, Thanks, Please…', totalQuestions: 5,
      ),
    ];
  }
}

