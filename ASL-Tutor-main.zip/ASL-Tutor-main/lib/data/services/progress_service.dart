import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ProgressService {
  static String _uid() => FirebaseAuth.instance.currentUser!.uid;
  
  static DateTime? _sessionStartTime;
  
  static void startSession() {
    _sessionStartTime = DateTime.now();
  }
  
  static int getElapsedMinutes() {
    if (_sessionStartTime == null) return 0;
    final elapsed = DateTime.now().difference(_sessionStartTime!);
    return elapsed.inMinutes;
  }
  
  static int stopSession() {
    final minutes = getElapsedMinutes();
    _sessionStartTime = null;
    return minutes;
  }
  
  static Future<void> saveSessionTime() async {
    final minutes = getElapsedMinutes();
    if (minutes > 0) {
      await addTimeSpent(minutes);
    }
    _sessionStartTime = null;
  }

  // Mark a level as completed for a lesson (e.g., 'alphabet' or 'phrases').
  //
  // - Saves progress under: users/{uid}/progress/{lessonKey}
  // - If this level was not previously completed:
  //    * adds it to `completed`
  //    * +100 XP
  //    * +3 signsLearned
  //    * updates streak / longestStreak / lastActiveDate
  //     * adds time spent from session timer
  static Future<void> markLevelComplete({
    required String lessonKey,
    required int levelIndex,
    required int totalLevels,
  }) async {
    final db = FirebaseFirestore.instance;
    final uid = _uid();
    final userRef = db.collection('users').doc(uid);
    final progressRef = userRef.collection('progress').doc(lessonKey);
    
    final timeSpentMinutes = stopSession();

    await db.runTransaction((tx) async {
      final progSnap = await tx.get(progressRef);
      final userSnap = await tx.get(userRef);

      final progData = progSnap.data();
      final userData = userSnap.data() ?? {};

      List<dynamic> completedRaw =
          (progData?['completed'] as List?) ?? <dynamic>[];

      final completed = <int>[];
      for (final v in completedRaw) {
        if (v is int) {
          completed.add(v);
        } else {
          final parsed = int.tryParse(v.toString());
          if (parsed != null) completed.add(parsed);
        }
      }

      final alreadyComplete = completed.contains(levelIndex);
      if (!alreadyComplete) {
        completed.add(levelIndex);
      }

      final storedTotal = (progData?['totalLevels'] is int)
          ? progData!['totalLevels'] as int
          : totalLevels;

      tx.set(
        progressRef,
        {
          'totalLevels': storedTotal,
          'completed': completed,
          'updatedAt': FieldValue.serverTimestamp(),
        },
        SetOptions(merge: true),
      );

      int _toInt(dynamic v) {
        if (v == null) return 0;
        if (v is int) return v;
        if (v is num) return v.toInt();
        final parsed = int.tryParse(v.toString());
        return parsed ?? 0;
      }

      if (alreadyComplete) {
        if (timeSpentMinutes > 0) {
          int currentTime = _toInt(userData['timeSpentMinutes']);
          tx.set(
            userRef,
            {'timeSpentMinutes': currentTime + timeSpentMinutes},
            SetOptions(merge: true),
          );
        }
        return;
      }

      int xp = _toInt(userData['xp']);
      int signsLearned = _toInt(userData['signsLearned']);
      int streak = _toInt(userData['streak']);
      int longestStreak = _toInt(userData['longestStreak']);
      int totalTimeMinutes = _toInt(userData['timeSpentMinutes']);

      xp += 100;
      signsLearned += 3;
      
      if (timeSpentMinutes > 0) {
        totalTimeMinutes += timeSpentMinutes;
      }

      final now = DateTime.now().toUtc();
      final today = DateTime(now.year, now.month, now.day);

      String _dateToStr(DateTime d) {
        final y = d.year.toString().padLeft(4, '0');
        final m = d.month.toString().padLeft(2, '0');
        final dd = d.day.toString().padLeft(2, '0');
        return '$y-$m-$dd';
      }

      DateTime? lastActiveDate;
      final rawLast = userData['lastActiveDate'];

      if (rawLast is String) {
        final parts = rawLast.split('-');
        if (parts.length == 3) {
          final y = int.tryParse(parts[0]);
          final m = int.tryParse(parts[1]);
          final d = int.tryParse(parts[2]);
          if (y != null && m != null && d != null) {
            lastActiveDate = DateTime.utc(y, m, d);
          }
        }
      } else if (rawLast is Timestamp) {
        final d = rawLast.toDate().toUtc();
        lastActiveDate = DateTime(d.year, d.month, d.day);
      }

      if (lastActiveDate == null) {
        streak = 1;
      } else {
        final diffDays = today.difference(lastActiveDate).inDays;
        if (diffDays == 0) {
          // same day → keep streak
        } else if (diffDays == 1) {
          // consecutive day → +1
          streak += 1;
        } else {
          // gap ≥2 days → reset
          streak = 1;
        }
      }

      if (streak > longestStreak) {
        longestStreak = streak;
      }

      tx.set(
        userRef,
        {
          'xp': xp,
          'signsLearned': signsLearned,
          'streak': streak,
          'longestStreak': longestStreak,
          'lastActiveDate': _dateToStr(today),
          'timeSpentMinutes': totalTimeMinutes,
        },
        SetOptions(merge: true),
      );
    });
  }

  // Stream the document for a lesson's progress.
  static Stream<DocumentSnapshot<Map<String, dynamic>>> lessonProgress(
      String lessonKey) {
    return FirebaseFirestore.instance
        .collection('users')
        .doc(_uid())
        .collection('progress')
        .doc(lessonKey)
        .snapshots();
  }
  
  static Future<void> addTimeSpent(int minutes) async {
    if (minutes <= 0) return;
    
    final db = FirebaseFirestore.instance;
    final uid = _uid();
    final userRef = db.collection('users').doc(uid);
    
    await userRef.set({
      'timeSpentMinutes': FieldValue.increment(minutes),
    }, SetOptions(merge: true));
  }
}

int _toInt(dynamic v) {
  if (v == null) return 0;
  if (v is int) return v;
  if (v is num) return v.toInt();
  final parsed = int.tryParse(v.toString());
  return parsed ?? 0;
}