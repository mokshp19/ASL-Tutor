import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AuthService {
  static final _auth = FirebaseAuth.instance;
  static final _db = FirebaseFirestore.instance;


  //  SIGN UP — creates the user document with default stats

  static Future<User?> signUp({
    required String name,
    required String email,
    required String password,
  }) async {
    final cred = await _auth.createUserWithEmailAndPassword(
      email: email,
      password: password,
    );

    final uid = cred.user!.uid;

    await _db.collection('users').doc(uid).set({
      'name': name,
      'email': email,

      // ---- streak stats ----
      'streak': 0,
      'longestStreak': 0,
      'lastActiveDate': null,

      // ---- xp / time ----
      'xp': 0,
      'timeSpentMinutes': 0,

      // ---- login counters ----
      'loginCount': 0,
      'lastLoginAt': FieldValue.serverTimestamp(),

      'createdAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));

    return cred.user;
  }


  // LOGIN — updates login count and longest streak logic only

  static Future<User?> signIn({
    required String email,
    required String password,
  }) async {
    final cred = await _auth.signInWithEmailAndPassword(
      email: email,
      password: password,
    );

    final uid = cred.user!.uid;
    final docRef = _db.collection('users').doc(uid);

    await _db.runTransaction((tx) async {
      final snap = await tx.get(docRef);
      final data = snap.data() ?? {};

      int loginCount = (data['loginCount'] ?? 0) as int;
      loginCount++;

      int streak = (data['streak'] ?? 0) as int;
      int longestStreak = (data['longestStreak'] ?? 0) as int;


      if (streak > longestStreak) {
        longestStreak = streak;
      }

      tx.update(docRef, {
        'loginCount': loginCount,
        'longestStreak': longestStreak,
        'lastLoginAt': FieldValue.serverTimestamp(),
      });
    });

    return cred.user;
  }

  /// -------------------------------------------------------
  ///  SIGN OUT
  /// -------------------------------------------------------
  static Future<void> signOut() => _auth.signOut();
}
