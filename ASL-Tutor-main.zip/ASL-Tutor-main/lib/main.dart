import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';

import 'presentation/screens/home_page.dart';
import 'presentation/screens/notifications.dart';
// If you used FlutterFire CLI, uncomment this and the options below
// import 'firebase_options.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    // If you generated firebase_options.dart with FlutterFire CLI, use:
    // options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const DailySignsApp());
}

class DailySignsApp extends StatelessWidget {
  const DailySignsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'DailySigns',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF41D05F)),
      ),
      home: const NotificationPage(),
    );
  }
}
