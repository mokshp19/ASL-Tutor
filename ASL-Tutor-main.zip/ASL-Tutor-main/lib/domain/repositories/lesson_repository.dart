import '../entities/lesson.dart';

abstract class LessonRepository {
  Future<List<Lesson>> fetchLessons();
  Future<Lesson?> fetchLessonById(String id);
}
