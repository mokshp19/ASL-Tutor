class Lesson {
  final String id;
  final String title;
  final String description;
  final int totalQuestions;

  const Lesson({
    required this.id,
    required this.title,
    required this.description,
    required this.totalQuestions,
  });

  factory Lesson.fromJson(Map<String, dynamic> json) => Lesson(
    id: json['id'] as String,
    title: json['title'] as String,
    description: json['description'] as String,
    totalQuestions: json['totalQuestions'] as int,
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'description': description,
    'totalQuestions': totalQuestions,
  };
}
